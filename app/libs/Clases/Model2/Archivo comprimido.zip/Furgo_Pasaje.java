
import java.util.*;

/**
 * 
 */
public class Furgo_Pasaje extends Furgoneta implements Pasajeros, Pasajeros {

    /**
     * Default constructor
     */
    public Furgo_Pasaje() {
    }

}
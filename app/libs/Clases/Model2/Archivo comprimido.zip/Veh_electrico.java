
import java.util.*;

/**
 * 
 */
public interface Veh_electrico {

}
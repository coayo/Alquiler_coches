
import java.util.*;

/**
 * 
 */
public class Vehiculo_carga extends Vehiculo {

    /**
     * Default constructor
     */
    public Vehiculo_carga() {
    }

    /**
     * 
     */
    public void Tonelaje;

}

import java.util.*;

/**
 * 
 */
public class Coche_Gas extends Vehiculo_pasaje {

    /**
     * Default constructor
     */
    public Coche_Gas() {
    }

    /**
     * 
     */
    public void Rendimiento;

}

import java.util.*;

/**
 * 
 */
public class Coche extends Coche_electrico {

    /**
     * Default constructor
     */
    public Coche() {
    }

}
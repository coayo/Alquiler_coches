
import java.util.*;

/**
 * 
 */
public class Furgoneta {

    /**
     * Default constructor
     */
    public Furgoneta() {
    }

}
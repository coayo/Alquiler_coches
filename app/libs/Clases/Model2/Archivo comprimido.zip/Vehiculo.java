
import java.util.*;

/**
 * 
 */
public class Vehiculo extends Moto {

    /**
     * Default constructor
     */
    public Vehiculo() {
    }

    /**
     * 
     */
    public void CantRuedas;

    /**
     * 
     */
    public void Motor;

    /**
     * 
     */
    public void Matricula;

    /**
     * 
     */
    public void Color;

    /**
     * 
     */
    public void Tipo_Carnet;

}

import java.util.*;

/**
 * 
 */
public interface Pasajeros {

    /**
     * 
     */
    public void Cant_pasj;

}

import java.util.*;

/**
 * 
 */
public interface Reparto {

}
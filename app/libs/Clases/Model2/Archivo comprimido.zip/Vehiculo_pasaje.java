
import java.util.*;

/**
 * 
 */
public class Vehiculo_pasaje extends Vehiculo {

    /**
     * Default constructor
     */
    public Vehiculo_pasaje() {
    }

    /**
     * 
     */
    public void Cant_Pasajeros;

}
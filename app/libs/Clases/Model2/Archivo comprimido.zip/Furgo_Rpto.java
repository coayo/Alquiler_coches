
import java.util.*;

/**
 * 
 */
public class Furgo_Rpto extends Furgoneta implements Reparto, Reparto {

    /**
     * Default constructor
     */
    public Furgo_Rpto() {
    }

}
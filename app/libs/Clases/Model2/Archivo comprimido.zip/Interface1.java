
import java.util.*;

/**
 * 
 */
public interface Interface1 {

}
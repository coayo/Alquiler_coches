
import java.util.*;

/**
 * 
 */
public class Coche_electrico extends Vehiculo_pasaje implements Veh_electrico {

    /**
     * Default constructor
     */
    public Coche_electrico() {
    }

    /**
     * 
     */
    public void Autonomia;

}
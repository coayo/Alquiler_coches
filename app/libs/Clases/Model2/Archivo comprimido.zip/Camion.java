
import java.util.*;

/**
 * 
 */
public class Camion extends Vehiculo_carga implements Pasajeros, Reparto {

    /**
     * Default constructor
     */
    public Camion() {
    }

}

import java.util.*;

/**
 * 
 */
public class Moto extends Vehiculo_pasaje {

    /**
     * Default constructor
     */
    public Moto() {
    }

}

import java.util.*;

/**
 * 
 */
public interface Combustible {

}